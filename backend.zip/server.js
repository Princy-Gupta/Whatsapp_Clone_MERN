// imports

import express from 'express'
import mongoose from 'mongoose'
import Cors from 'cors';
import Messages from './dbMsg.js'
import Pusher from 'pusher'
// app config

const app= express()
const port=process.env.PORT || 5000
const connection_url='mongodb+srv://admin-princy:princy31@cluster0.tmbdi.mongodb.net/whatsappDB?retryWrites=true&w=majority'

const pusher = new Pusher({
    appId: "1199761",
    key: "8ea8d10fb03ca12eaf94",
    secret: "091d4a0d6c9e36004336",
    cluster: "ap2",
    useTLS: true
  });


//middleware- middleware gives you access to req and res in the apps request-> response cycle.

app.use(express.json());
app.use(Cors());

//DB config
mongoose.connect(connection_url,{
    useNewUrlParser:true,
    useCreateIndex:true,
    useUnifiedTopology:true
});




//api routes
const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', function() {
  console.log("connected");
  const msgC= db.collection("whatsappmessages");
  const changeStream= msgC.watch();
  //You can watch for changes to a single collection, a database, or an entire deployment in 
  //MongoDB with Change Streams. Open a change stream by calling the watch() method 
  //on a Collection, Db, or MongoClient object. The change stream emits change event documents when they occur.

  changeStream.on('change',change => {
      console.log(change);
      if(change.operationType === "insert")
      {
          const messD=change.fullDocument
          //Change streams allow applications to access real-time data changes 
          //without the complexity and risk of tailing the oplog. 
          //Applications can use change streams to subscribe to all data changes on a single collection, 
          //a database, or an entire deployment, and immediately react to them. 

          pusher.trigger("messages","inserted",{

            name:messD.name,
            message:messD.message,
            timestamp:messD.timestamp,
            received:messD.received
          })
      }
      else{
          console.log("error pusher triggering");
      }
  })
});

app.get('/',(req,res)=>{
    res.send("Whatsapp clone ");
})


app.get('/messages/sync',(req,res)=>{
    Messages.find((err,data)=>{
        if(err)
        console.log(err);
        else
        res.send(data);
    })
})

app.post('/messages/new',(req,res)=>{
    const dbMessage=req.body;
    Messages.create(dbMessage,(err,data)=>{
        if(err)
        {
            console.log(err);
        }
        else{
            res.send(data);
        }
    })
})

//listen

app.listen(port,()=>{
    console.log(`Listening on port:${port}`);
});









//Cross-Origin Resource Sharing. It is a mechanism to allow or restrict requested resources 
//on a web server depend on where the HTTP request was initiated.
//URL being accessed differs from the location that the JavaScript is running from, by having
//secure cross-origin requests and data transfers between browsers and servers.
// when we have our frontend and backend with diffrenet domain names