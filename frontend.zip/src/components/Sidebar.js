/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
import React from 'react';
import './Sidebar.css';
import DonutLargerIcon from '@material-ui/icons/DonutLarge';
import ChatIcon from '@material-ui/icons/Chat';
import MoreVertIcom from '@material-ui/icons/MoreVert';
import {Avatar,IconButton} from '@material-ui/core'
import {SearchOutlined} from '@material-ui/icons';
import SidebarChat from './SidebarChat';
import { useStateValue } from './StateProvider';
const Sidebar = ({messages}) => {
    const [{user},dispatch] = useStateValue();
    return (
        <div className="sidebar">
            <div className="sidebar_header">
                <Avatar src={user?.photoURL} />
                <div className="sidebar_headerRight">
                    <IconButton >
                        <DonutLargerIcon />
                    </IconButton>
                    <IconButton>
                        <ChatIcon />
                    </IconButton>
                    <IconButton>
                        <MoreVertIcom />
                    </IconButton>
                </div>
            </div>
            <div className="sidebar_search">
                <div className="sidebar_searchContainer">
                    <SearchOutlined/>
                    <input type="text" placeholder="Search" or start new chat/>
                </div>
            </div>
            <div className="sidebar_chat"> <SidebarChat messages={messages}/>
           </div>
           
        </div>
    )
}

export default Sidebar
