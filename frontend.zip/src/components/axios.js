import axios from 'axios'

const inst= axios.create({
    baseURL:"https://whatsapp-clone31.herokuapp.com"
})


export default inst;


////https://whatsapp-clone31.herokuapp.com/
//https://localhost:5000