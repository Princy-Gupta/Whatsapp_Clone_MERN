/* eslint-disable no-lone-blocks */
/* eslint-disable no-undef */
import React,{useState, useEffect} from 'react'
import './SidebarChat.css'
import {Avatar} from '@material-ui/core'
const SidebarChat = ({messages}) => {
    const[seed, setSeed]= useState("");

    {/* side effects mount-worksone tym, update works-again and again, unmount-clear interval, useeffect runs after every render*/}
       {/* we pass array so as to change only those params which are specified in array*/}
       {/* we unmount the component still the event is being listened on  therefore cleanup as such unmount */}
    useEffect(() => {             
       setSeed(Math.floor(Math.random()*5000))
    }, []) 
    return (
        <div className="sidebarChat">
           
            <Avatar src={`https://avatars.dicebear.com/api/human/b${seed}.svg`}/>  {/*  random picture  */}
            <div className="sidebarChat_info">
                <h2>Dev Help</h2>
                <p>{messages[messages.length-1]?.message}</p>
            </div>
            
        </div>
    )
}

export default SidebarChat
