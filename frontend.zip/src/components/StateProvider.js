import React,{createContext, useContext, useReducer} from 'react'
export const StateContext= createContext(); //comes with a provider and consumer react component
export const StateProvider =({reducer,initialState,children})=>( //APP.JS
    <StateContext.Provider value={useReducer(reducer,initialState)}> 
        {children}
    </StateContext.Provider>
) 

export const useStateValue = () => useContext(StateContext); //makes consuming way simpler




//context provides a way to pass data through the component tree without having to pass  props down manually at each level
//provider is responsible for proving value to all decandants
//use Reducer is alt to useState
//difference-  useState is build using useReducer i.e reducer is more primitive in nature it is the parent.