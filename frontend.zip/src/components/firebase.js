import firebase from 'firebase/app';
import 'firebase/auth'; // for authentication
import 'firebase/storage'; //for storage
import 'firebase/database'; // for reatime db
import 'firebase/firestore'; //for cloud firestore

const firebaseConfig = {
    apiKey: "AIzaSyCrhjpxSSDj9qiDiTifXmWAEHJO9-p2WWw",
    authDomain: "whatsapp-clone31.firebaseapp.com",
    projectId: "whatsapp-clone31",
    storageBucket: "whatsapp-clone31.appspot.com",
    messagingSenderId: "854325198056",
    appId: "1:854325198056:web:3085e56e06875158be5d5d"
  };

  const firebaseApp= firebase.initializeApp(firebaseConfig)
  const db=firebaseApp.firestore();
  const auth= firebase.auth();
  const provider= new firebase.auth.GoogleAuthProvider();
  export {auth, provider}
  export default db